/**
 * Modified FDK-derived AAC-ELD-only decoder. See NOTICE and MODIFICATIONS.txt.
 * Raw access units only. No RTP, encryption, ADTS, SBR, MPS or resilience tools.
 */
export function createEldDecoder({ sampleRate = 44100, channels = 2, frameLength = 480, sbr = false } = {}) {
  if (sbr) return Promise.reject(new RangeError('This ELD build does not support SBR.'));
  if (![44100, 48000].includes(sampleRate) || ![1, 2].includes(channels) || ![480, 512].includes(frameLength)) {
    return Promise.reject(new RangeError('Supported ELD configurations: 44100/48000 Hz, mono/stereo, 480/512 samples.'));
  }
  return new Promise((resolve, reject) => {
    let engine;
    engine = createFDK({
      memoryInitializerRequest: { status: 200, response: eldMemory },
      onAbort(reason) { reject(new Error('ELD initialization aborted: ' + reason)); },
      onRuntimeInitialized() {
        // The factory may initialize before it returns; defer access to engine.
        Promise.resolve().then(() => {
          let inputPointer = 0;
          let input = null;
          let output = null;
          try {
            inputPointer = engine._malloc(8192);
            if (!inputPointer) throw new Error('ELD input allocation failed.');
            input = new Uint8Array(engine.HEAPU8.buffer, inputPointer, 8192);
            input.set([0xf8, sampleRate === 44100 ? 0xe8 : 0xe6,
              (channels << 5) | (frameLength === 480 ? 0x10 : 0), 0]);
            const status = engine._init(inputPointer, 4);
            if (status) throw new Error('ELD configuration failed: 0x' + status.toString(16));
            output = new Int16Array(engine.HEAPU8.buffer, engine._pcm_ptr(), frameLength * channels);
            let closed = false;
            const live = () => { if (closed) throw new Error('ELD decoder is closed.'); };
            const check = status => {
              // FDK's 0x4000..0x4fff errors provide valid concealment PCM.
              if (status && (status < 0x4000 || status > 0x4fff)) {
                const error = new Error('ELD decode failed: 0x' + status.toString(16)); error.code = status; throw error;
              }
              return status;
            };
            const bytes = packet => {
              if (packet instanceof Uint8Array) return packet;
              if (packet instanceof ArrayBuffer) return new Uint8Array(packet);
              throw new TypeError('Expected a Uint8Array or ArrayBuffer containing one raw ELD access unit.');
            };
            const api = {
              sampleRate, channels, frameLength, lastStatus: 0,
              /** Borrowed interleaved PCM16, overwritten by the next decode/reset. */
              decode(packet, copy = false) {
                live(); const data = bytes(packet);
                if (!data.byteLength || data.byteLength > input.length) throw new RangeError('ELD packet must contain 1..8192 bytes.');
                input.set(data); api.lastStatus = engine._decode(inputPointer, data.byteLength); check(api.lastStatus);
                return copy ? output.slice() : output;
              },
              /** Decode and copy PCM into an existing caller-owned destination. */
              decodeInto(packet, destination) {
                live();
                if (!(destination instanceof Int16Array) || destination.length < output.length) throw new RangeError('Destination must be a sufficiently large Int16Array.');
                destination.set(api.decode(packet)); return output.length;
              },
              /** Conceal a missing access unit; report status via lastStatus. */
              conceal(copy = false) {
                live(); api.lastStatus = engine._conceal(); check(api.lastStatus); return copy ? output.slice() : output;
              },
              reset() {
                live(); input.set([0xf8, sampleRate === 44100 ? 0xe8 : 0xe6,
                  (channels << 5) | (frameLength === 480 ? 0x10 : 0), 0]);
                check(engine._init(inputPointer, 4)); output.fill(0); api.lastStatus = 0;
              },
              close() {
                if (closed) return;
                engine._close_decoder(); engine._free(inputPointer); output.fill(0); closed = true;
                inputPointer = 0; input = null; output = null; engine = null;
              },
            };
            resolve(api);
          } catch (error) {
            engine._close_decoder(); if (inputPointer) engine._free(inputPointer); reject(error);
          }
        }).catch(reject);
      },
    });
  });
}
