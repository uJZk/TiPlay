#!/usr/bin/env bash
set -euo pipefail
eld_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
: "${EMSDK:?Set EMSDK to an emsdk installation with sdk-fastcomp-1.39.0-64bit activated}"
source "$EMSDK/emsdk_env.sh"
python3 - <<'PY'
import subprocess
v=subprocess.check_output(['emcc','--version'],text=True)
if '1.39.0' not in v:raise SystemExit('Use Emscripten 1.39.0 fastcomp for true asm.js; modern WASM=0 is wasm2js, not this build.')
PY
eld_compiler_root="$EMSDK/fastcomp/emscripten"
python3 - "$eld_root" "$eld_compiler_root" <<'PY'
from pathlib import Path
import sys
root,compiler=map(Path,sys.argv[1:]);s=(compiler/'cmake/Modules/Platform/Emscripten.cmake').read_text().replace('cmake_minimum_required(VERSION 3.0.0)','cmake_minimum_required(VERSION 3.5)')
(root/'toolchain.cmake').write_text('set(EMSCRIPTEN_ROOT_PATH "'+str(compiler)+'")\n'+s)
PY
"${CMAKE_BIN:-cmake}" -S "$eld_root" -B "$eld_root/build" \
  -DCMAKE_TOOLCHAIN_FILE="$eld_root/toolchain.cmake" -DCMAKE_BUILD_TYPE=Release \
  '-DCMAKE_CXX_FLAGS_RELEASE=-O3 -DNDEBUG' '-DCMAKE_C_FLAGS_RELEASE=-O3 -DNDEBUG' \
  '-DCMAKE_EXE_LINKER_FLAGS_RELEASE=-O3' \
  '-DCMAKE_EXE_LINKER_FLAGS=-O3 -s WASM=0 -s MODULARIZE=1 -s EXPORT_NAME=createFDK -s EXPORTED_FUNCTIONS=["_init","_decode","_conceal","_close_decoder","_samples","_delay","_pcm_ptr","_malloc","_free"] -s TOTAL_MEMORY=16777216 -s ENVIRONMENT=web,worker'
"${CMAKE_BIN:-cmake}" --build "$eld_root/build" -j "${ELD_BUILD_JOBS:-4}"
python3 "$eld_root/package.py"
