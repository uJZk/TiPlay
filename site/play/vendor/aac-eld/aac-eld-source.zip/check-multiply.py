from pathlib import Path
import subprocess
root=Path(__file__).parent
s=(root/'fdk/libFDK/include/fixmul.h').read_text();start=s.index('inline LONG eld_mulhi32');end=s.index('#if !defined(FUNCTION_fixmuldiv2_DD)',start)
code='''#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <climits>
typedef int32_t LONG;typedef int32_t INT;typedef uint32_t UINT;typedef int16_t SHORT;
'''+s[start:end]+'''
void check(int32_t a,int32_t b){int32_t h=eld_mulhi32(a,b),r=(int32_t)(((int64_t)a*b)>>32);if(h!=r){fprintf(stderr,"high mismatch %d %d %d %d\\n",a,b,h,r);exit(1);}int16_t c=(int16_t)a;h=eld_mulshift16(c,b);r=(int32_t)(((int64_t)c*b)>>16);if(h!=r){fprintf(stderr,"mixed mismatch\\n");exit(1);}}
int main(){int32_t edge[]={INT_MIN,INT_MIN+1,-65536,-65535,-32768,-1,0,1,32767,65535,65536,INT_MAX-1,INT_MAX};for(int32_t a:edge)for(int32_t b:edge)check(a,b);uint32_t x=12345;for(int i=0;i<2000000;i++){x=x*1664525+1013904223;int32_t a=x;x=x*1664525+1013904223;check(a,(int32_t)x);}puts("PASS 169 boundary pairs + 2000000 random pairs, both operations; UBSan");}
'''
(root/'multiply-check.cpp').write_text(code)
subprocess.run(['g++','-O2','-fsanitize=undefined','-fno-sanitize-recover=all',str(root/'multiply-check.cpp'),'-o',str(root/'multiply-check')],check=True)
subprocess.run([str(root/'multiply-check')],check=True)
