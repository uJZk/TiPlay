/* Modified build: SBR and MPEG Surround are intentionally unsupported. */
#include "sbrdecoder.h"
#include "sac_dec_lib.h"
SBR_ERROR sbrDecoder_Open(HANDLE_SBRDECODER *pSelf, HANDLE_FDK_QMF_DOMAIN pQmfDomain) { *pSelf = NULL; return (SBR_ERROR)0; }
SBR_ERROR sbrDecoder_InitElement(HANDLE_SBRDECODER self, const int sampleRateIn, const int sampleRateOut, const int samplesPerFrame, const AUDIO_OBJECT_TYPE coreCodec, const MP4_ELEMENT_ID elementID, const int elementIndex, const UCHAR harmonicSBR, const UCHAR stereoConfigIndex, const UCHAR configMode, UCHAR *configChanged, const INT downscaleFactor) {  return (SBR_ERROR)1; }
SBR_ERROR sbrDecoder_FreeMem(HANDLE_SBRDECODER *self) {  return (SBR_ERROR)0; }
INT sbrDecoder_Header(HANDLE_SBRDECODER self, HANDLE_FDK_BITSTREAM hBs, const INT sampleRateIn, const INT sampleRateOut, const INT samplesPerFrame, const AUDIO_OBJECT_TYPE coreCodec, const MP4_ELEMENT_ID elementID, const INT elementIndex, const UCHAR harmonicSBR, const UCHAR stereoConfigIndex, const UCHAR configMode, UCHAR *configChanged, const INT downscaleFactor) {  return (INT)1; }
SBR_ERROR sbrDecoder_SetParam(HANDLE_SBRDECODER self, const SBRDEC_PARAM param, const INT value) {  return (SBR_ERROR)0; }
SBR_ERROR sbrDecoder_drcFeedChannel(HANDLE_SBRDECODER self, INT ch, UINT numBands, FIXP_DBL *pNextFact_mag, INT nextFact_exp, SHORT drcInterpolationScheme, UCHAR winSequence, USHORT *pBandTop) {  return (SBR_ERROR)0; }
void sbrDecoder_drcDisable(HANDLE_SBRDECODER self, INT ch) {  }
SBR_ERROR sbrDecoder_Parse(HANDLE_SBRDECODER self, HANDLE_FDK_BITSTREAM hBs, UCHAR *pDrmBsBuffer, USHORT drmBsBufferSize, int *count, int bsPayLen, int crcFlag, MP4_ELEMENT_ID prev_element, int element_index, UINT acFlags, UINT acElFlags[]) {  return (SBR_ERROR)1; }
SBR_ERROR sbrDecoder_Apply(HANDLE_SBRDECODER self, LONG *input, LONG *timeData, const int timeDataSize, int *numChannels, int *sampleRate, const FDK_channelMapDescr *const mapDescr, const int mapIdx, const int coreDecodedOk, UCHAR *psDecoded, const INT inDataHeadroom, INT *outDataHeadroom) {  return (SBR_ERROR)1; }
SBR_ERROR sbrDecoder_Close(HANDLE_SBRDECODER *self) {  return (SBR_ERROR)0; }
INT sbrDecoder_GetLibInfo(LIB_INFO *info) {  return (INT)0; }
UINT sbrDecoder_GetDelay(const HANDLE_SBRDECODER self) {  return (UINT)0; }
SAC_INSTANCE_AVAIL mpegSurroundDecoder_IsFullMpegSurroundDecoderInstanceAvailable(CMpegSurroundDecoder *pMpegSurroundDecoder) {  return (SAC_INSTANCE_AVAIL)0; }
SACDEC_ERROR mpegSurroundDecoder_Open(CMpegSurroundDecoder **pMpegSurroundDecoder, int stereoConfigIndex, HANDLE_FDK_QMF_DOMAIN pQmfDomain) { *pMpegSurroundDecoder = NULL; return (SACDEC_ERROR)0; }
SACDEC_ERROR mpegSurroundDecoder_Init(CMpegSurroundDecoder *pMpegSurroundDecoder) {  return (SACDEC_ERROR)0; }
SACDEC_ERROR mpegSurroundDecoder_Config(CMpegSurroundDecoder *pMpegSurroundDecoder, HANDLE_FDK_BITSTREAM hBs, AUDIO_OBJECT_TYPE coreCodec, INT samplingRate, INT frameSize, INT numChannels, INT stereoConfigIndex, INT coreSbrFrameLengthIndex, INT configBytes, const UCHAR configMode, UCHAR *configChanged) {  return (SACDEC_ERROR)1; }
SACDEC_ERROR mpegSurroundDecoder_ConfigureQmfDomain(CMpegSurroundDecoder *pMpegSurroundDecoder, SAC_INPUT_CONFIG sac_dec_interface, UINT coreSamplingRate, AUDIO_OBJECT_TYPE coreCodec) {  return (SACDEC_ERROR)1; }
int mpegSurroundDecoder_ParseNoHeader(CMpegSurroundDecoder *pMpegSurroundDecoder, HANDLE_FDK_BITSTREAM hBs, int *pMpsDataBits, int fGlobalIndependencyFlag) {  return (int)1; }
int mpegSurroundDecoder_Parse(CMpegSurroundDecoder *pMpegSurroundDecoder, HANDLE_FDK_BITSTREAM hBs, int *pMpsDataBits, AUDIO_OBJECT_TYPE coreCodec, int sampleRate, int frameSize, int fGlobalIndependencyFlag) {  return (int)1; }
int mpegSurroundDecoder_Apply(CMpegSurroundDecoder *pMpegSurroundDecoder, PCM_MPS *input, PCM_MPS *pTimeData, const int timeDataSize, int timeDataFrameSize, int *nChannels, int *frameSize, int sampleRate, AUDIO_OBJECT_TYPE coreCodec, AUDIO_CHANNEL_TYPE channelType[], UCHAR channelIndices[], const FDK_channelMapDescr *const mapDescr, const INT inDataHeadroom, INT *outDataHeadroom) {  return (int)1; }
void mpegSurroundDecoder_Close(CMpegSurroundDecoder *pMpegSurroundDecoder) {  }
SACDEC_ERROR mpegSurroundDecoder_FreeMem(CMpegSurroundDecoder *pMpegSurroundDecoder) {  return (SACDEC_ERROR)0; }
SACDEC_ERROR mpegSurroundDecoder_SetParam(CMpegSurroundDecoder *pMpegSurroundDecoder, const SACDEC_PARAM param, const INT value) {  return (SACDEC_ERROR)0; }
int mpegSurroundDecoder_GetLibInfo(LIB_INFO *libInfo) {  return (int)0; }
UINT mpegSurroundDecoder_GetDelay(const CMpegSurroundDecoder *self) {  return (UINT)0; }
SACDEC_ERROR mpegSurroundDecoder_IsPseudoLR(CMpegSurroundDecoder *pMpegSurroundDecoder, int *bsPseudoLr) {  return (SACDEC_ERROR)0; }
