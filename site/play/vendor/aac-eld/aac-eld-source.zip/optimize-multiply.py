from pathlib import Path
p=Path(__file__).parent/'fdk/libFDK/include/fixmul.h';s=p.read_text();anchor=s.index('#if !defined(FUNCTION_fixmuldiv2_DD)');s=s[:anchor]+'''// Modified asm.js build: exact signed high multiply using only 32-bit limbs.
// Avoid Fastcomp's general-purpose emulated 64-bit multiplication.
inline LONG eld_mulhi32(const LONG a, const LONG b) {
  const INT a0 = (UINT)a & 65535, a1 = a >> 16;
  const INT b0 = (UINT)b & 65535, b1 = b >> 16;
  const UINT w0 = (UINT)a0 * (UINT)b0;
  const INT t = a1 * b0 + (INT)(w0 >> 16);
  const INT w1 = a0 * b1 + (t & 65535);
  return a1 * b1 + (t >> 16) + (w1 >> 16);
}
inline LONG eld_mulshift16(const SHORT a, const LONG b) {
  return (INT)a * (b >> 16) + (((INT)a * (INT)((UINT)b & 65535)) >> 16);
}
\n'''+s[anchor:];s=s.replace('(LONG)((((INT64)a) * b) >> 32)','eld_mulhi32(a, b)').replace('((LONG)((((INT64)a) * b) >> 32))','eld_mulhi32(a, b)').replace('(LONG)((((INT64)a) * b) >> 16)','eld_mulshift16(a, b)',1)
# The second mixed-width overload reverses its operands.
s=s.replace('(LONG)((((INT64)a) * b) >> 16)','eld_mulshift16(b, a)',1)
s=s.replace('(LONG)(((((INT64)a) * b) >> 16) << 1)','(LONG)((UINT)eld_mulshift16(a, b) << 1)',1).replace('(LONG)(((((INT64)a) * b) >> 16) << 1)','(LONG)((UINT)eld_mulshift16(b, a) << 1)',1)
p.write_text(s)
