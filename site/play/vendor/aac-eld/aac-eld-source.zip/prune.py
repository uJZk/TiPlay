from pathlib import Path
import re
root=Path(__file__).parent/'fdk'
def replace_body(s,anchor,body):
 start=s.index('{',s.index(anchor));level=1;i=start+1
 while level:
  if s[i]=='{':level+=1
  elif s[i]=='}':level-=1
  i+=1
 return s[:start+1]+'\n'+body+'\n'+s[i-1:]
p=root/'libFDK/src/FDK_tools_rom.cpp';s=p.read_text();s=replace_body(s,'const element_list_t *getBitstreamElementList(','''  if (aot != AOT_ER_AAC_ELD || epConfig != 0) return NULL;
  if (nChannels == 1) return &node_eld_sce_epc0;
  if (nChannels == 2) return &node_eld_cpe_epc0;
  return NULL;''');p.write_text(s)
p=root/'libAACdec/src/aacdecoder.cpp';s=p.read_text();offset=s.index('CAacDecoder_Init(HANDLE_AACDECODER self');start=s.index('  switch (asc->m_aot) {',offset);end=s.index('\n\n  if (CProgramConfig_',start);s=s[:start]+'''  if (asc->m_aot != AOT_ER_AAC_ELD || asc->m_channelConfiguration < 1 ||
      asc->m_channelConfiguration > 2 || asc->m_sbrPresentFlag || asc->m_epConfig != 0)
    return AAC_DEC_UNSUPPORTED_FORMAT;
  initRenderMode = AACDEC_RENDER_ELDFB;'''+s[end:];p.write_text(s)
p=root/'libMpegTPDec/src/tpdec_asc.cpp';s=p.read_text();anchor=s.index('/* Parse whatever specific configs */');start=s.index('switch (self->m_aot)',anchor);end=s.index('\n\n  /* Frame length */',start);s=s[:start]+'''if (self->m_aot != AOT_ER_AAC_ELD) return TRANSPORTDEC_UNSUPPORTED_FORMAT;
  if ((ErrorStatus = EldSpecificConfig_Parse(self, bs, cb)) != TRANSPORTDEC_OK)
    return ErrorStatus;
  if (self->m_sc.m_eldSpecificConfig.m_sbrPresentFlag)
    return TRANSPORTDEC_UNSUPPORTED_FORMAT;
  frameLengthFlag = self->m_sc.m_eldSpecificConfig.m_frameLengthFlag;
  self->m_sbrPresentFlag = 0;
  self->m_extensionSamplingFrequency = self->m_samplingFrequency;'''+s[end:];p.write_text(s)
# Supported input configuration is synthesized by the narrow wrapper. These
# disabled flags remove non-ELD branches from generic hot functions at compile time.
p=root/'libSYS/include/FDK_audio.h';s=p.read_text();anchor=s.index('#define AC_CM_DET_CFG_CHANGE');disabled=['AC_USAC','AC_RSV603DA','AC_RSVD50','AC_SBR_PRESENT','AC_PS_PRESENT','AC_MPS_PRESENT','AC_DRM','AC_DAB','AC_SCALABLE','AC_BSAC','AC_HDAAC','AC_SAOC_PRESENT','AC_ELD_DOWNSCALE','AC_LD_MPS','AC_ER_HCR','AC_ER_RVLC','AC_ER_VCB11'];s=s[:anchor]+'\n/* Modified ELD-only build: other profiles/extensions are not supported. */\n'+''.join(f'#undef {x}\n#define {x} 0\n' for x in disabled)+s[anchor:];p.write_text(s)
# Retain the upstream ABI for disabled extensions, without their implementations.
stubs=['/* Modified build: SBR and MPEG Surround are intentionally unsupported. */','#include "sbrdecoder.h"','#include "sac_dec_lib.h"']
for name,prefix in [('libSBRdec/include/sbrdecoder.h','sbrDecoder_'),('libSACdec/include/sac_dec_lib.h','mpegSurroundDecoder_')]:
 h=(root/name).read_text();h=re.sub(r'/\*.*?\*/','',h,flags=re.S);h=re.sub(r'//[^\n]*','',h)
 for m in re.finditer(r'\b([A-Za-z_]\w*)\s+('+prefix+r'\w+)\s*\((.*?)\)\s*;',h,re.S):
  ret,fn,args=m.groups();args=' '.join(args.split());body=''
  if fn=='sbrDecoder_Open':body='*pSelf = NULL;'
  if fn=='mpegSurroundDecoder_Open':body='*pMpegSurroundDecoder = NULL;'
  reject=any(x in fn for x in ['InitElement','Header','_Config','_Parse','_Apply'])
  if ret!='void':body+=f' return ({ret})'+('1' if reject else '0')+';'
  stubs.append(f'{ret} {fn}({args}) {{ {body} }}')
(root/'eld_stubs.cpp').write_text('\n'.join(stubs)+'\n')
p=root/'CMakeLists.txt';s=p.read_text();start=s.index('set(libfdk_aac_SOURCES');end=s.index('\n\nif(WIN32',start);s=s[:start]+'''set(libfdk_aac_SOURCES
    ${AACDEC_SRC} ${ARITHCODING_SRC} ${DRCDEC_SRC} ${MPEGTPDEC_SRC}
    ${PCMUTILS_SRC} ${FDK_SRC} ${SYS_SRC} eld_stubs.cpp)'''+s[end:];p.write_text(s)
(root/'MODIFICATIONS.txt').write_text('Modified ELD-only derivative of mstorsjo/fdk-aac v2.0.3, commit 716f4394641d53f0d79c9ddac3fa93b03a49f278. Not an upstream release. See ../prune.py for transformations. Only raw AAC-ELD, no SBR/MPS/resilience, epConfig=0; other formats rejected. Preserve NOTICE and original copyright notices.\n')
