// Candidate benchmark: main-thread packet -> module Worker -> owned PCM transfer.
// Run: NODE_PATH=/workspace/work/eld-js/node_modules node worker-stream-check.cjs
// ELD_ROOT may point at an independently built candidate directory.
const fs = require('fs');
const http = require('http');
const path = require('path');
const { chromium } = require('playwright');
const root = process.env.ELD_ROOT || '/workspace/work/eld-js';
(async () => {
  const server = http.createServer((request, response) => {
    if (request.url === '/') { response.end('<!doctype html>'); return; }
    const filename = path.resolve(root, '.' + request.url.split('?')[0]);
    if (!filename.startsWith(root + '/')) { response.writeHead(403).end(); return; }
    response.setHeader('Content-Type', filename.endsWith('.js') ? 'text/javascript' : 'application/octet-stream');
    fs.readFile(filename, (error, bytes) => { if (error) response.writeHead(404).end(); else response.end(bytes); });
  });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  let browser;
  try {
    browser = await chromium.launch({ executablePath: '/usr/bin/chromium', headless: true, args: ['--no-sandbox'] });
    const page = await browser.newPage();
    await page.goto('http://127.0.0.1:' + server.address().port);
    const result = await page.evaluate(async () => {
      const bytes = await (await fetch('/fixtures/44100-2-480-2.bin')).arrayBuffer();
      const view = new DataView(bytes); let position = 0;
      function next() { const length = view.getUint32(position, true); position += 4; const packet = bytes.slice(position, position + length); position += length; return packet; }
      next(); const frames = []; while (position < bytes.byteLength) frames.push(next());
      const source = `import { createEldDecoder } from '${location.origin}/dist/aac-eld.js';
        const decoder = await createEldDecoder();
        self.onmessage = ({ data }) => { const start = performance.now(); const pcm = decoder.decode(data.packet, true); const computeMs = performance.now() - start; self.postMessage({ id: data.id, pcm: pcm.buffer, computeMs }, [pcm.buffer]); };
        self.postMessage({ ready: true });`;
      const url = URL.createObjectURL(new Blob([source], { type: 'text/javascript' }));
      const worker = new Worker(url, { type: 'module' });
      const pending = new Map(); const rows = []; let inFlight = 0; let maxInFlight = 0;
      let fatal; const failed = new Promise((_, reject) => { fatal = reject; });
      failed.catch(() => {});
      let ready; const initialized = new Promise(resolve => { ready = resolve; });
      worker.onerror = event => fatal(new Error(event.message));
      worker.onmessage = ({ data }) => {
        if (data.ready) { ready(); return; }
        const record = pending.get(data.id); if (!record) { fatal(new Error('Unknown frame')); return; }
        const now = performance.now(); pending.delete(data.id); inFlight--;
        if (data.pcm.byteLength !== 1920) { fatal(new Error('Invalid PCM size')); return; }
        rows.push({ id: data.id, rtt: now - record.sent, scheduledToPcm: now - record.target, dispatchLate: record.sent - record.target, compute: data.computeMs });
      };
      try {
        await Promise.race([initialized, failed]);
        const period = 480 / 44100 * 1000; const start = performance.now() + 20;
        const total = 1200; // First 200 frames are warmup; no intentional batching.
        for (let id = 0; id < total; id++) {
          const target = start + id * period;
          while (target > performance.now()) await new Promise(resolve => setTimeout(resolve, Math.max(0, target - performance.now())));
          const packet = frames[id % frames.length].slice(0); const sent = performance.now();
          pending.set(id, { target, sent }); maxInFlight = Math.max(maxInFlight, ++inFlight);
          worker.postMessage({ id, packet }, [packet]);
        }
        const deadline = performance.now() + 10000;
        while (pending.size && performance.now() < deadline) await Promise.race([new Promise(resolve => setTimeout(resolve, 10)), failed]);
        if (pending.size) throw new Error('Worker timeout, pending=' + pending.size);
        const measured = rows.filter(row => row.id >= 200);
        const stats = key => { const values = measured.map(row => row[key]).sort((a,b) => a-b); return { p50: values[Math.floor(values.length*.5)], p95: values[Math.floor(values.length*.95)], p99: values[Math.floor(values.length*.99)], max: values.at(-1) }; };
        return { scope: 'main->Worker->main only; excludes Worklet, playback and network', total, measured: measured.length, period, maxInFlight, overOneFrame: measured.filter(row => row.scheduledToPcm > period).length, rtt: stats('rtt'), scheduledToPcm: stats('scheduledToPcm'), dispatchLate: stats('dispatchLate'), compute: stats('compute') };
      } finally { worker.terminate(); URL.revokeObjectURL(url); }
    });
    console.log(JSON.stringify(result, null, 2));
  } finally { if (browser) await browser.close(); await new Promise(resolve => server.close(resolve)); }
})().catch(error => { console.error(error); process.exitCode = 1; });
