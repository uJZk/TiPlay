/* Narrow API for a modified ELD-only FDK build; see fdk/MODIFICATIONS.txt. */
#include "aacdecoder_lib.h"
static HANDLE_AACDECODER h = 0;
static INT_PCM pcm[1024];
extern "C" {
int init(unsigned char *p, int n) {
  // Accept only the eight canonical no-SBR/no-resilience configurations.
  if (!p || n != 4 || p[0] != 0xf8 || (p[1] != 0xe6 && p[1] != 0xe8) ||
      (p[2] != 0x20 && p[2] != 0x30 && p[2] != 0x40 && p[2] != 0x50) || p[3])
    return AAC_DEC_UNSUPPORTED_FORMAT;
  if (h) aacDecoder_Close(h);
  h = aacDecoder_Open(TT_MP4_RAW, 1);
  if (!h) return AAC_DEC_OUT_OF_MEMORY;
  UINT len = n;
  int err = aacDecoder_ConfigRaw(h, &p, &len);
  if (err) { aacDecoder_Close(h); h = 0; }
  return err;
}
int decode(unsigned char *p, int n) {
  if (!h) return AAC_DEC_INVALID_HANDLE;
  if (!p || n < 1 || n > 8192) return AAC_DEC_UNSUPPORTED_FORMAT;
  UINT len = n, valid = n;
  int err = aacDecoder_Fill(h, &p, &len, &valid);
  if (err) return err;
  if (valid) return AAC_DEC_UNKNOWN;
  return aacDecoder_DecodeFrame(h, pcm, 1024, 0);
}
int conceal() {
  if (!h) return AAC_DEC_INVALID_HANDLE;
  return aacDecoder_DecodeFrame(h, pcm, 1024, AACDEC_CONCEAL);
}
void close_decoder() { if (h) aacDecoder_Close(h); h = 0; }
int samples() { return h ? aacDecoder_GetStreamInfo(h)->frameSize : 0; }
int delay() { return h ? aacDecoder_GetStreamInfo(h)->outputDelay : 0; }
int pcm_ptr() { return (int)(long)pcm; }
}
